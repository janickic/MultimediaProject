# CMPT365 Project

This project was written in Python 2.7.13. It should work for any Python 2.7 release.  

1) Please ensure you are running the correct version of Python  
$ python -V  
(Python download here: https://www.python.org/downloads/)  

2) Run requirements.txt before running the project  
$ pip install -r requirements.txt  

3) Run the project  
$ python project.py  